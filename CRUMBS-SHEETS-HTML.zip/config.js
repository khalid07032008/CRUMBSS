window.CRUMBS_CONFIG = {
  sheetsUrl: "https://script.google.com/macros/s/AKfycbzVkv8ERPJrU7Ik1hH1HK3aJCJw7U01mLbfW0w3bfd_e3YoF_SlDMHMGZeFEFucP_wZIA/exec"
};
