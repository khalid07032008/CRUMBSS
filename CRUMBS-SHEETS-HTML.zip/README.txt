CRUMBS HTML + GOOGLE SHEETS

Extract all files together. Upload this folder to an HTTP/HTTPS static host; index.html is the home page.
config.js already contains your Apps Script /exec URL.
Checked 2026-10-01: endpoint returned ok:true, ready:true. Invalid POST was rejected with a readable JSON response and Access-Control-Allow-Origin: *.
A complete valid application has not been submitted as part of testing. Confirm that your first real application appears in CRUMBS_WL_NEW.
Keep your Google Sheet private. No secrets or applicant records are included in this package.
