(() => {
 const audioBase=new URL("assets/audio/",document.currentScript.src);
 const Engine=window.AudioContext||window.webkitAudioContext;
 let ctx,master,loading,sources=[],wanted=true,failed=false;
 const buttons=()=>document.querySelectorAll('[data-rooftop-sound]');
 const audible=()=>wanted&&ctx?.state==='running'&&sources.length>0;
 function paint(){buttons().forEach(b=>{b.textContent=failed?'SOUND UNAVAILABLE':audible()?'◖ PIGEONS · MUTE':wanted?'◖ SOUND READY · MUTE':'◖ PIGEONS · UNMUTE';b.setAttribute('aria-pressed',String(wanted));b.setAttribute('aria-label',wanted?'Mute pigeon ambience':'Unmute pigeon ambience');b.title=audible()?'Pigeon ambience is playing':wanted?'Sound starts automatically when your browser allows it, or on your first interaction.':'Pigeon ambience is muted'})}
 function setup(){
  if(ctx&&ctx.state!=='closed')return;
  ctx=new Engine();master=ctx.createGain();master.gain.value=.5;master.connect(ctx.destination);ctx.onstatechange=paint;failed=false;
  loading=Promise.all(['dove','pigeon'].map(async name=>{const r=await fetch(new URL(name+'.ogg',audioBase));if(!r.ok)throw Error('Audio unavailable');return ctx.decodeAudioData(await r.arrayBuffer())})).then(buffers=>{
   const started=ctx.currentTime+.05;
   [[0,.36,-.45,1,0],[1,.22,.45,1,2.2],[0,.12,.7,.94,4.1]].forEach(([index,volume,pan,rate,offset])=>{
    const source=ctx.createBufferSource(),gain=ctx.createGain(),stereo=ctx.createStereoPanner();source.buffer=buffers[index];source.loop=true;source.playbackRate.value=rate;gain.gain.value=volume;stereo.pan.value=pan;source.connect(gain);gain.connect(stereo);stereo.connect(master);source.start(started,offset%source.buffer.duration);sources.push(source);
   });paint();
  }).catch(()=>{failed=true;paint()});
 }
 function attempt(){if(!wanted||!Engine)return;setup();master.gain.setTargetAtTime(.5,ctx.currentTime,.15);ctx.resume().then(paint).catch(paint);paint()}
 function mute(){wanted=false;if(ctx)master.gain.setTargetAtTime(0,ctx.currentTime,.05);paint()}
 document.addEventListener('click',e=>{if(e.target.closest('[data-rooftop-sound]')){if(wanted)mute();else{wanted=true;attempt()}}});
 function unlock(e){if(wanted&&ctx?.state!=='running'&&!e.target.closest?.('[data-rooftop-sound]'))attempt()}
 ['pointerdown','touchend','keydown','click'].forEach(type=>document.addEventListener(type,unlock,{passive:true}));
 window.addEventListener('pagehide',()=>{sources.forEach(s=>{try{s.stop()}catch{}});sources=[];ctx?.close().catch(()=>{})});
 window.addEventListener('pageshow',e=>{if(e.persisted){ctx=undefined;attempt()}});
 window.crumbsSound={refresh:paint};paint();attempt();
})();
