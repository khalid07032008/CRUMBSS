(() => {
  const stage = document.querySelector('#collection-stage');
  const lanes = document.querySelector('#collection-lanes');
  const grid = document.querySelector('#collection-grid');
  const dialog = document.querySelector('#portrait-dialog');
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  let paused = reduced.matches;
  const toggle = document.querySelector('#motion-toggle');
  function updateMotion(){ stage.classList.toggle('motion-paused',paused); toggle.textContent=paused?'Resume motion ▶':'Pause motion ⏸'; toggle.setAttribute('aria-pressed',String(paused)); }
  toggle.addEventListener('click',()=>{paused=!paused;updateMotion()});
  reduced.addEventListener('change',event=>{paused=event.matches;updateMotion()});
  updateMotion();
  function card(n,duplicate=false){
    const id=String(n).padStart(3,'0');
    const button=document.createElement('button');button.type='button';button.className='collection-card';
    button.setAttribute('aria-label',`View CRUMBS #${id}`);
    const img=document.createElement('img');img.src=`assets/collection/${id}.webp`;img.alt=`CRUMBS pigeon portrait ${id}`;img.loading='lazy';img.decoding='async';img.width=180;img.height=180;
    const caption=document.createElement('span');caption.textContent=`CRUMBS #${id}`;button.append(img,caption);
    if(duplicate){button.tabIndex=-1;button.setAttribute('aria-hidden','true')}
    button.addEventListener('click',()=>{const large=document.querySelector('#large-portrait');large.src=img.src;large.alt=img.alt;document.querySelector('#portrait-title').textContent=`CRUMBS #${id}`;dialog.showModal()});
    return button;
  }
  for(let row=0;row<3;row++){
    const lane=document.createElement('div');lane.className='collection-lane';lane.style.setProperty('--duration',`${190+row*25}s`);
    for(let repeat=0;repeat<2;repeat++)for(let n=row*37+1;n<=(row+1)*37;n++)lane.append(card(n,repeat===1));
    lanes.append(lane);
  }
  const all=document.querySelector('#view-all');
  all.addEventListener('click',()=>{if(!grid.children.length)for(let n=1;n<=111;n++)grid.append(card(n));grid.hidden=!grid.hidden;all.setAttribute('aria-expanded',String(!grid.hidden));all.textContent=grid.hidden?'Explore all 111 ↗':'Close gallery ↑'});
  document.querySelector('#close-portrait').addEventListener('click',()=>dialog.close());
  dialog.addEventListener('click',e=>{if(e.target===dialog){const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dialog.close()}});
})();
